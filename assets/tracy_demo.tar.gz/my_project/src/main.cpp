#if defined(__clang__) || defined(__GNUC__)
#  define TracyFunction __PRETTY_FUNCTION__
#elif defined(_MSC_VER)
#  define TracyFunction __FUNCSIG__
#endif

#include <tracy/Tracy.hpp>

#include <iostream>
// include header file for sleep func
#include <unistd.h>
#include <thread>

void thread1_func()
{
    ZoneScopedNCS("thread1", 0x00ff00, TRACY_HAS_CALLSTACK);
    FrameMarkNamed("thread1");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

void thread2_func()
{
    ZoneScopedNCS("thread2", 0x0000ff, TRACY_HAS_CALLSTACK);
    FrameMarkNamed("thread2");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

void thread3_func()
{
    ZoneScopedNCS("thread3", 0xbbc400, TRACY_HAS_CALLSTACK);
    FrameMarkNamed("thread3");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

void thread4_func()
{
    ZoneScopedNCS("thread4", 0xac4f5d, TRACY_HAS_CALLSTACK);
    FrameMarkNamed("thread4");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

void thread5_func()
{
    ZoneScopedNCS("thread5", 0x66ffee, TRACY_HAS_CALLSTACK);
    FrameMarkNamed("thread5");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

int main() {
    while (true)
    {
        sleep(1);
        std::cout << "Once more calling..." << std::endl;
        // ZoneScopedNS("demo", TRACY_HAS_CALLSTACK);
        ZoneScopedNCS("demo", 0xff0000, TRACY_HAS_CALLSTACK);

        std::thread t1(thread1_func);
        auto rand_time_ms = rand() % 1000 + 100;
        std::this_thread::sleep_for(std::chrono::milliseconds(rand_time_ms));
        std::thread t2(thread2_func);
        rand_time_ms = rand() % 1000 + 100;
        std::this_thread::sleep_for(std::chrono::milliseconds(rand_time_ms));
        std::thread t3(thread3_func);
        rand_time_ms = rand() % 1000 + 100;
        std::this_thread::sleep_for(std::chrono::milliseconds(rand_time_ms));
        std::thread t4(thread4_func);
        rand_time_ms = rand() % 1000 + 100;
        std::this_thread::sleep_for(std::chrono::milliseconds(rand_time_ms));
        std::thread t5(thread5_func);
        t1.join();
        t2.join();
        t3.join();
        t4.join();
        t5.join();

        auto ptr = new int[100];
        TracyAlloc(ptr, 100 * sizeof(int));
        TracyMessage("Allocated 100 ints", 100 * sizeof(int));
        TracyFree(ptr);
        TracyMessage("Freed 100 ints", 100 * sizeof(int));
        delete[] ptr;
    }
    
    return 0;
}