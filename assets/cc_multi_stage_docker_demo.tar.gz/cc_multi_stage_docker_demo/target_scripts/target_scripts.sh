#!/bin/bash

# 替换arm64的apt源
sed -i 's/ports.ubuntu.com/mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/g' /etc/apt/sources.list

# 安装必要的库
apt update && apt install -y vim curl wget

# 安装ROS Noetic
wget http://fishros.com/install -O fishros && bash fishros

# 安装其他依赖包
apt install -y g++-aarch64-linux-gnu
apt install -y ros-noetic-cv-bridge
apt install -y libprotobuf-dev protobuf-compiler libzmq3-dev

# clean apt cache
apt clean
rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*