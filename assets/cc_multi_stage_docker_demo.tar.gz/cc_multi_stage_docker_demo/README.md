# ARM64 交叉编译 Docker 环境

这个项目提供了一个用于ARM64架构交叉编译的Docker环境。它使用多阶段构建来创建一个完整的ARM64开发环境，支持SSH远程访问和交叉编译工具链的配置。

## 目录结构

```
.
├── dockerfile           # 多阶段Docker构建文件
├── scripts/            # 通用脚本目录
│   ├── fix_cmake_files.py     # 修复CMAKE文件中的绝对路径问题
│   └── fix_rootfs_softlink.py # 修复rootfs中的软链接
├── host_scripts/       # 主机端脚本目录
│   ├── catkin_build.sh      # Catkin构建脚本，只用于ros工作空间
│   ├── host_scripts.sh      # 主机环境配置脚本
│   ├── toolchain.cmake      # 交叉编译工具链配置
│   └── fish_install.yaml    # fishros一键安装配置，只为了添加ros源
└── target_scripts/     # 目标环境脚本目录
    ├── target_scripts.sh    # 目标环境配置脚本
    └── fish_install.yaml    # fishros一键安装配置，安装ros-noetic
```

## 配置步骤

1. 安装 Docker（如果尚未安装）:
   ```bash
   # 请参考Docker官方文档进行安装
   # https://docs.docker.com/engine/install/
   ```

2. 启用 Docker 的 buildx（支持多架构构建）:
   ```bash
   docker buildx create --use
   ```

3. 安装 QEMU 支持:
   ```bash
   # 在x86机器上模拟 ARM64 环境
   sudo apt-get install qemu qemu-user-static
   ```

4. 启用 QEMU 支持:
   ```bash
   docker run --rm --privileged multiarch/qemu-user-static --reset -p yes
   ```

5. 构建Docker镜像:
   ```bash
   # 在项目根目录下执行
   docker build -t arm64-dev-env .
   ```

6. 运行容器:
   ```bash
   docker run -d -p 2345:2345 arm64-dev-env
   ```

## 主要功能

- 多阶段构建过程：
  1. 构建ARM64 rootfs
  2. 安装必要的软件包
  3. 配置开发环境

- 支持SSH远程访问（端口2345）
- 预配置交叉编译工具链
- 自动修复路径和软链接
- 清华源镜像加速

## 使用说明

1. SSH连接：
   ```bash
   ssh root@localhost -p 2345
   # 默认密码: root
   ```

2. 交叉编译：
   - 使用预配置的toolchain.cmake进行交叉编译
   - 支持Catkin工作空间的构建

## 注意事项

- 请确保Docker服务正在运行
- 需要足够的磁盘空间（约4GB）
- 首次构建可能需要较长时间
- 建议使用清华源以加快下载速度

# 如何开发自己的docker镜像

修改 target_scripts.sh 和 host_scripts.sh 文件，根据需要添加自己的项目依赖即可