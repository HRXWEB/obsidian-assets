#!/bin/bash

sed -i 's/archive.ubuntu.com/mirrors.tuna.tsinghua.edu.cn/g' /etc/apt/sources.list && \
    sed -i 's/security.ubuntu.com/mirrors.tuna.tsinghua.edu.cn/g' /etc/apt/sources.list

apt update && apt install -y vim curl wget rsync

# 安装ROS Noetic
wget http://fishros.com/install -O fishros && bash fishros

# 安装其他依赖包
apt install -y g++-aarch64-linux-gnu protobuf-compiler
apt install -y ros-noetic-catkin python3-catkin-tools python3-catkin

# apt clean
apt clean
rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*