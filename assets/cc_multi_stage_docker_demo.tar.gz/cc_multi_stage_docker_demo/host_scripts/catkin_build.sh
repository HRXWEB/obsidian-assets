#!/bin/bash

# 取消 ros 带来的环境变量
unset CMAKE_PREFIX_PATH
unset LD_LIBRARY_PATH
# unset PYTHONPATH
unset ROS_PACKAGE_PATH

# 设置交叉编译参数
export CMAKE_TOOLCHAIN_FILE=/workspace/toolchain.cmake
export TARGET_ABI=arm64
export CMAKE_SYSTEM_PROCESSOR=aarch64
export CMAKE_PREFIX_PATH=/rootfs/opt/ros/noetic
export ROS_PACKAGE_PATH=/rootfs/opt/ros/noetic/share
export PKG_CONFIG_PATH=/rootfs/opt/ros/noetic/lib/pkgconfig

# 执行catkin_make
catkin_make \
  -DCMAKE_SKIP_RPATH=TRUE \
  -DCMAKE_TOOLCHAIN_FILE=$CMAKE_TOOLCHAIN_FILE \
  -DTARGET_ABI=$TARGET_ABI \
  -DCMAKE_SYSTEM_PROCESSOR=$CMAKE_SYSTEM_PROCESSOR

# install
catkin_make install

# rm .catkin_workspace
rm -rf .catkin_workspace
